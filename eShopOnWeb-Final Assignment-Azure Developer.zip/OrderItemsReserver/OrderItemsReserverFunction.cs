using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Azure.Storage.Blobs;
using System.Collections.Generic;
using System.Text;
using Microsoft.Azure.Cosmos;
using Azure.Messaging.ServiceBus;
using Microsoft.Azure.Cosmos.Core;
using Azure.Core;
using System.Net;
using System.Configuration;
using System.Net.Http;

namespace OrderItemsReserver
{
    public static class OrderItemsReserverFunction
    {
        [FunctionName("OrderItemsReserverFunction")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            log.LogInformation("C# HTTP trigger function processed a request.");

            #region Azure service bus queue
            //namespace connection string
            var namespaceConnectionString = "Endpoint=sb://eshoponwebnamespace.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=PLcgBL/KpfsK4dUWqgcUow7bYIQpGQGpu+ASbDJmrxg=";
            string queueName = "eshoponwebqueue";

            // the client that owns the connection and can be used to create senders and receivers
            ServiceBusClient sbClient = new ServiceBusClient(namespaceConnectionString);

            // the sender used to publish messages to the queue
            ServiceBusProcessor sbProcessor = null;

            // Create the clients that we'll use for sending and processing messages.            
            sbProcessor = sbClient.CreateProcessor(queueName);

            sbProcessor.ProcessMessageAsync += OrderMessageHandler;
            sbProcessor.ProcessErrorAsync += OrderErrorHandler;

            try
            {
                // Use the producer client to send the batch of messages to the Service Bus queue
                await sbProcessor.StartProcessingAsync();
                Console.WriteLine("Waiting for order details from queue");
                Console.ReadKey();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                // Calling DisposeAsync on client types is required to ensure that network
                // resources and other unmanaged objects are properly cleaned up.
                if (sbProcessor != null)
                    await sbProcessor.StopProcessingAsync();
            }
            #endregion

            Order order = new Order()
            {
                Id = Guid.NewGuid().ToString(),
                Units = Convert.ToInt32(req.Query["units"]),
                BasketId = Convert.ToInt32(req.Query["basketId"]),
                Address = req.Query["address"],
                ProductName = req.Query["productName"],
                BuyerId = req.Query["buyerId"],
                UnitPrice = Convert.ToInt32(req.Query["unitPrice"]),                
            };

            #region function generated code
            // Retrieve the model id from the query string
            string name = req.Query["name"];

            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            dynamic data = JsonConvert.DeserializeObject(requestBody);
            name = name ?? data?.name;

            string responseMessage = string.IsNullOrEmpty(name)
                ? "This HTTP triggered function executed successfully. Pass a name in the query string or in the request body for a personalized response."
                : $"Hello, {name}. This HTTP triggered function executed successfully.";

            return new OkObjectResult(responseMessage);
            #endregion
        }

        private static async Task OrderMessageHandler(ProcessMessageEventArgs args)
        {
            string orderData = string.Empty;
            try
            {
                #region Save order json to Azure Blob storage
                orderData = args.Message.Body.ToString();
                Console.WriteLine("Received " + orderData);

                string Connection = "DefaultEndpointsProtocol=https;AccountName=eshoponwebstorageaccount;AccountKey=tfjRPJ14LAleY7o4H2t7z/q96A+choO6PitE2wv7q7I+HDXebC5UFyxAlneJ1+9wXy10G0sAEmQC+AStNhr8Xg==;EndpointSuffix=core.windows.net";
                string containerName = "eshoponweb-json-file-upload";

                BlobClientOptions blobOptions = new BlobClientOptions()
                {
                    Retry = {
                                Delay = TimeSpan.FromSeconds(2),
                                MaxRetries = 3,
                                Mode = RetryMode.Exponential,
                                MaxDelay = TimeSpan.FromSeconds(10),
                                NetworkTimeout = TimeSpan.FromSeconds(100)
                            },
                };

                Stream myBlob = new MemoryStream(Encoding.UTF8.GetBytes(orderData));
                var blobClient = new BlobContainerClient(Connection, containerName, blobOptions);
                var blob = blobClient.GetBlobClient("orderjsonFile2");
                await blob.UploadAsync(myBlob);
                #endregion         

                // complete the message. messages is deleted from the queue.
                await args.CompleteMessageAsync(args.Message);
            }
            catch (System.Exception ex)
            {
                Console.WriteLine(ex.ToString());

                //var url = @"https://prod-84.eastus.logic.azure.com:443/workflows/6060366f4a7a464982d6420e9c6bb3bb/triggers/manual/paths/invoke?api-version=2016-10-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=fGt7Bdevj-mG11zXodaf0LaNqGm2-5g8XVf0SCeoxa4";
                //WebRequest request = HttpWebRequest.Create(url);
                //WebResponse response = request.GetResponse();
                //StreamReader reader = new StreamReader(response.GetResponseStream());

                #region Send mail using Logic Apps
                var client = new HttpClient();                
                HttpResponseMessage result = await client.PostAsync(
                "https://prod-84.eastus.logic.azure.com:443/workflows/6060366f4a7a464982d6420e9c6bb3bb/triggers/manual/paths/invoke?api-version=2016-10-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=fGt7Bdevj-mG11zXodaf0LaNqGm2-5g8XVf0SCeoxa4",
                new StringContent(orderData, Encoding.UTF8, "application/json"));

                var statusCode = result.StatusCode.ToString();
                #endregion
            }
        }

        private static Task OrderErrorHandler(ProcessErrorEventArgs args)
        {
            throw new NotImplementedException();
        }

    }

    class Order
    {
        [JsonProperty(PropertyName = "id")]
        public string Id { get; set; }
        public int BasketId { get; set; }
        public string Address { get; set; }
        public string ProductName { get; set; }
        public string BuyerId { get; set; }
        public int UnitPrice { get; set; }
        public int Units { get; set; }
    }
}
