using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Collections.Concurrent;
using System.ComponentModel;
using Microsoft.Azure.Cosmos;


namespace DeliveryOrderProcessor
{
    public static class DeliveryOrderProcessorFunction
    {
        [FunctionName("DeliveryOrderProcessorFunction")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            log.LogInformation("C# HTTP trigger function processed a request.");

            Order order = new Order()
            {
                Id = Guid.NewGuid().ToString(),
                Units = Convert.ToInt32(req.Query["units"]),
                BasketId = Convert.ToInt32(req.Query["basketId"]),
                Address = req.Query["address"],
                ProductName = req.Query["productName"],
                BuyerId = req.Query["buyerId"],
                UnitPrice = Convert.ToInt32(req.Query["unitPrice"]),
            };

            #region Cosmos DB
            //Connecting and saving to cosmos DB
            // Replace <documentEndpoint> with the information created earlier
            string EndpointUri = "https://eshoponwebeastus.documents.azure.com:443/";

            // Set variable to the Primary Key from earlier.
            string PrimaryKey = "CyvlINZpaHryLlCBRFbtP8QjRsbRRSfZ62UjMfFz0qx7Dr0P6fdzwESkK3PUlnQwcOh8k5xqY1XeACDb5KhfVw==";

            // The Cosmos client instance
            CosmosClient cosmosClient = new CosmosClient(EndpointUri, PrimaryKey);

            // The database we will create
            Database database = cosmosClient.GetDatabase("orderdb");

            // The container we will create.
            Microsoft.Azure.Cosmos.Container container = database.GetContainer("order"); ;

            Order createdOrder = await container.CreateItemAsync<Order>(
                                                        item: order,
                                                        partitionKey: new PartitionKey(order.Id)
                                                    );
            #endregion

            #region Function Generated code
            string name = req.Query["name"];

            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            dynamic data = JsonConvert.DeserializeObject(requestBody);
            name = name ?? data?.name;

            string responseMessage = string.IsNullOrEmpty(name)
                ? "This HTTP triggered function executed successfully. Pass a name in the query string or in the request body for a personalized response."
                : $"Hello, {name}. This HTTP triggered function executed successfully.";

            return new OkObjectResult(responseMessage);
            #endregion
        }
    }

    class Order
    {
        [JsonProperty(PropertyName = "id")]
        public string Id { get; set; }
        public int BasketId { get; set; }
        public string Address { get; set; }
        public string ProductName { get; set; }
        public string BuyerId { get; set; }
        public int UnitPrice { get; set; }
        public int Units { get; set; }
    }
}
