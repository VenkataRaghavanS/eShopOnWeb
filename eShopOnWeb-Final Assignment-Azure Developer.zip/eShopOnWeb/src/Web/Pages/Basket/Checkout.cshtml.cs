﻿using System.Runtime.ConstrainedExecution;
using Ardalis.GuardClauses;
using Azure.Messaging.ServiceBus;
using BlazorAdmin;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.eShopWeb.ApplicationCore.Entities.OrderAggregate;
using Microsoft.eShopWeb.ApplicationCore.Exceptions;
using Microsoft.eShopWeb.ApplicationCore.Interfaces;
using Microsoft.eShopWeb.Infrastructure.Identity;
using Microsoft.eShopWeb.Web.Interfaces;
using Newtonsoft.Json;

namespace Microsoft.eShopWeb.Web.Pages.Basket;

[Authorize]
public class CheckoutModel : PageModel
{
    private readonly IBasketService _basketService;
    private readonly SignInManager<ApplicationUser> _signInManager;
    private readonly IOrderService _orderService;
    private string? _username = null;
    private readonly IBasketViewModelService _basketViewModelService;
    private readonly IAppLogger<CheckoutModel> _logger;

    public CheckoutModel(IBasketService basketService,
        IBasketViewModelService basketViewModelService,
        SignInManager<ApplicationUser> signInManager,
        IOrderService orderService,
        IAppLogger<CheckoutModel> logger)
    {
        _basketService = basketService;
        _signInManager = signInManager;
        _orderService = orderService;
        _basketViewModelService = basketViewModelService;
        _logger = logger;
    }

    public BasketViewModel BasketModel { get; set; } = new BasketViewModel();

    public async Task OnGet()
    {
        await SetBasketModelAsync();
    }

    public async Task<IActionResult> OnPost(IEnumerable<BasketItemViewModel> items)
    {
        try
        {
            await SetBasketModelAsync();

            if (!ModelState.IsValid)
            {
                return BadRequest();
            }

            var updateModel = items.ToDictionary(b => b.Id.ToString(), b => b.Quantity);
            await _basketService.SetQuantities(BasketModel.Id, updateModel);
            await _orderService.CreateOrderAsync(BasketModel.Id, new Address("123 Main St.", "Kent", "OH", "United States", "44240"));
            await _basketService.DeleteBasketAsync(BasketModel.Id);

            #region Azure service bus queue
            //Since the items are not coming in the OnPost Method, Created the object
            Order order = new Order()
            {
                Id = Guid.NewGuid().ToString(),
                Units = 1,
                BasketId = BasketModel.Id,
                Address = "123 Main St Kent OH US 44240",
                ProductName = ".NET Foundation Sheet",
                BuyerId = "demouser@microsoft.com",
                UnitPrice = 12,
            };

            string orderjson = JsonConvert.SerializeObject(order);
        
            //namespace connection string
            var namespaceConnectionString = "Endpoint=sb://eshoponwebnamespace.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=PLcgBL/KpfsK4dUWqgcUow7bYIQpGQGpu+ASbDJmrxg=";
            string queueName = "eshoponwebqueue";

            // the client that owns the connection and can be used to create senders and receivers
            ServiceBusClient sbClient;

            // the sender used to publish messages to the queue
            ServiceBusSender sender;
            
            // Create the clients that we'll use for sending and processing messages.
            sbClient = new ServiceBusClient(namespaceConnectionString);
            sender = sbClient.CreateSender(queueName);

            // create a batch 
            using ServiceBusMessageBatch messageBatch = await sender.CreateMessageBatchAsync();

            if (!messageBatch.TryAddMessage(new ServiceBusMessage(orderjson)))
            {
                // if it is too large for the batch
                throw new Exception($"The message is too large to fit in the batch.");
            }

            try
            {
                // Use the producer client to send the batch of messages to the Service Bus queue
                await sender.SendMessagesAsync(messageBatch);
                //Console.WriteLine($"A batch of {numOfMessages} messages has been published to the queue.");
            }
            finally
            {
                // Calling DisposeAsync on client types is required to ensure that network
                // resources and other unmanaged objects are properly cleaned up.
                await sender.DisposeAsync();
                await sbClient.DisposeAsync();
            }
            #endregion

            #region Call Order Items Reserver Function
            //We can add a config value and read the Function url from the config value
            string orderItemsReserverFunctionUrl = "http://localhost:7071/api/OrderItemsReserverFunction";
                      
            string urlQueryStringParams = $"?basketId=" + BasketModel.Id.ToString() + "&address=" + "123 Main St Kent OH US 44240" + "&productName=" + ".NET Foundation Sheet" + "&buyerId=" + "demouser@microsoft.com" + "&unitPrice=" + "12" + "&units=" + "1";

            using (HttpClient client = new HttpClient())
            {
                using (HttpResponseMessage res = await client.GetAsync(
                 $"{orderItemsReserverFunctionUrl}{urlQueryStringParams}"))
                {
                    using (HttpContent content = res.Content)
                    {
                        string data = await content.ReadAsStringAsync();
                        if (data != null)
                        {
                            _logger.LogInformation(data);
                        }
                        else
                            _logger.LogInformation("");
                    }
                }
            }
            #endregion

            #region Call Delivery Order Processor Function
            //We can add a config value and read the Function url from the config value
            string deliveryOrderProcessorFunctionUrl = "http://localhost:7014/api/DeliveryOrderProcessorFunction";

            urlQueryStringParams = $"?basketId=" + BasketModel.Id.ToString() + "&address=" + "123 Main St Kent OH US 44240" + "&productName=" + ".NET Foundation Sheet" + "&buyerId=" + "demouser@microsoft.com" + "&unitPrice=" + "12" + "&units=" + "1";

            using (HttpClient client = new HttpClient())
            {
                using (HttpResponseMessage res = await client.GetAsync(
                 $"{deliveryOrderProcessorFunctionUrl}{urlQueryStringParams}"))
                {
                    using (HttpContent content = res.Content)
                    {
                        string data = await content.ReadAsStringAsync();
                        if (data != null)
                        {
                            _logger.LogInformation(data);
                        }
                        else
                            _logger.LogInformation("");
                    }
                }
            }
            #endregion region
        }
        catch (EmptyBasketOnCheckoutException emptyBasketOnCheckoutException)
        {
            //Redirect to Empty Basket page
            _logger.LogWarning(emptyBasketOnCheckoutException.Message);
            return RedirectToPage("/Basket/Index");
        }

        return RedirectToPage("Success");
    }

    private async Task SetBasketModelAsync()
    {
        Guard.Against.Null(User?.Identity?.Name, nameof(User.Identity.Name));
        if (_signInManager.IsSignedIn(HttpContext.User))
        {
            BasketModel = await _basketViewModelService.GetOrCreateBasketForUser(User.Identity.Name);
        }
        else
        {
            GetOrSetBasketCookieAndUserName();
            BasketModel = await _basketViewModelService.GetOrCreateBasketForUser(_username!);
        }
    }

    private void GetOrSetBasketCookieAndUserName()
    {
        if (Request.Cookies.ContainsKey(Constants.BASKET_COOKIENAME))
        {
            _username = Request.Cookies[Constants.BASKET_COOKIENAME];
        }
        if (_username != null) return;

        _username = Guid.NewGuid().ToString();
        var cookieOptions = new CookieOptions();
        cookieOptions.Expires = DateTime.Today.AddYears(10);
        Response.Cookies.Append(Constants.BASKET_COOKIENAME, _username, cookieOptions);
    }
    class Order
    {
        [JsonProperty(PropertyName = "id")]
        public string Id { get; set; }
        public int BasketId { get; set; }
        public string Address { get; set; }
        public string ProductName { get; set; }
        public string BuyerId { get; set; }
        public int UnitPrice { get; set; }
        public int Units { get; set; }
    }
}
