﻿namespace BlazorShared.Models;

public abstract class LookupData
{
    public int Id { get; set; }
    public string Name { get; set; }
}
